package Lista1;

public class Q6 {

	public static void main(String[] args) {

		int x = 365;
		
		System.out.println(x);

	}

}
