package Lista1;

public class QuestaoD {

	public static void main(String[] args) {

		double media;

		media = (8 + 9 + 7) / 3;
		
		System.out.println("M�dia: "+media);

	}

}
