package Lista1;

public class QuestaoC {

	public static void main(String[] args) {
		
		int prod;
		
		prod = 28*43;
		
		System.out.println("28 * 43 = "+prod);

	}

}
